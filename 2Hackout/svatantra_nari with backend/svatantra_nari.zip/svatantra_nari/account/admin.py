from django.contrib import admin

from account.models import User

# Register your models here.
admin.site.register(User)